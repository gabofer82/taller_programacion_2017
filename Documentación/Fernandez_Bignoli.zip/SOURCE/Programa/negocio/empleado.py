# -*- coding: utf-8 -*-


class Empleado(object):
    pass