# -*- coding: utf-8 -*-


class AgendaDiaria(object):
    pass