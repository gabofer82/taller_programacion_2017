# -*- coding: utf-8 -*-


class ReservaAnalisis(object):
    pass