# -*- coding: utf-8 -*-


class LaboratorioExterno(object):
    pass