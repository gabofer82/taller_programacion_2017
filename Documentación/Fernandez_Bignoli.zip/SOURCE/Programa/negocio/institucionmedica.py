# -*- coding: utf-8 -*-


class InstitucionMedica(object):
    pass