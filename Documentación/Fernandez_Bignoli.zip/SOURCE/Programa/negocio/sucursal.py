# -*- coding: utf-8 -*-


class Sucursal(object):
    pass