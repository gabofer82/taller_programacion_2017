# -*- coding: utf-8 -*-


class Analisis(object):
    pass