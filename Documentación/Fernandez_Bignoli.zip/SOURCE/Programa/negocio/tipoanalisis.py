# -*- coding: utf-8 -*-


class TipoAnalisis(object):
    pass