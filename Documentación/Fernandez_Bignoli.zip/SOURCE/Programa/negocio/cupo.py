# -*- coding: utf-8 -*-


class Cupo(object):
    pass